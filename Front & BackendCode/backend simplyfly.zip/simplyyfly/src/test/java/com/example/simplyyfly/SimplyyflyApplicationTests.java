package com.example.simplyyfly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplyyflyApplicationTests {

	@Test
	void contextLoads() {
	}

}
