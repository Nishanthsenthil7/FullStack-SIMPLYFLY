package com.example.simplyyfly;

import com.example.simplyyfly.Items.*;
import com.example.simplyyfly.Repo.*;
import com.example.simplyyfly.datatransferobject.BookingRequest;
import com.example.simplyyfly.datatransferobject.BookingResponse;
import com.example.simplyyfly.service.EmailService;
import com.example.simplyyfly.service.BookingServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BookingServiceImplTest {

    @Mock private BookingRepository bookingRepository;
    @Mock private SeatRepository seatRepository;
    @Mock private UserRepository userRepository;
    @Mock private FlightRepository flightRepository;
    @Mock private EmailService emailService;

    @Mock private Authentication authentication;

    @InjectMocks
    private BookingServiceImpl bookingService;

    private User testUser;
    private Flight testFlight;
    private BookingRequest bookingRequest;

    @BeforeEach
    void setup() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("user@example.com");

        testFlight = new Flight();
        testFlight.setId(1L);
        testFlight.setFlightid("FL123");
        testFlight.setFlight("IndiGo Express");
        testFlight.setFare(2500.0);
        Route route = new Route();
        route.setOrigin("Chennai");
        route.setDestination("Delhi");
        testFlight.setRoute(route);

        bookingRequest = new BookingRequest();
        bookingRequest.setFlightId(1L);
        bookingRequest.setSeatCount(2);
        bookingRequest.setTravelDate(LocalDate.now().plusDays(5));
    }

    @Test
    void testBookFlight_Success() throws Exception {
        List<Seat> availableSeats = Arrays.asList(new Seat(), new Seat(), new Seat());
        when(authentication.getName()).thenReturn("user@example.com");
        when(userRepository.findByEmail("user@example.com")).thenReturn(Optional.of(testUser));
        when(flightRepository.findById(1L)).thenReturn(Optional.of(testFlight));
        when(seatRepository.findByFlightAndIsBookedFalse(testFlight)).thenReturn(availableSeats);
        when(bookingRepository.save(any(Booking.class))).thenAnswer(inv -> {
            Booking b = inv.getArgument(0);
            b.setId(100L);
            return b;
        });
        when(seatRepository.saveAll(anyList())).thenReturn(availableSeats);
        doNothing().when(emailService).sendBookingPdf(anyString(), any(), anyString());

        BookingResponse response = bookingService.bookFlight(bookingRequest, authentication);

        assertNotNull(response);
        assertEquals(100L, response.getBookingId());
        assertEquals("FL123", response.getFlightNumber());
        assertEquals(2, response.getSeatCount());
        assertEquals("BOOKED", response.getStatus());
    }


    @Test
    void testCancelBooking_Success() {
        Booking booking = new Booking();
        booking.setId(1L);
        booking.setStatus("BOOKED");
        booking.setUser(testUser);

        when(authentication.getName()).thenReturn("user@example.com");
        when(userRepository.findByEmail("user@example.com")).thenReturn(Optional.of(testUser));
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
        when(seatRepository.findByBookingId(1L)).thenReturn(new ArrayList<>());
        when(bookingRepository.save(any())).thenReturn(booking);

        String result = bookingService.cancelBooking(1L, authentication);
        assertEquals("Booking cancelled successfully.", result);
    }

    @Test
    void testCancelBooking_NotOwnedByUser() {
        User anotherUser = new User();
        anotherUser.setId(2L);
        Booking booking = new Booking();
        booking.setId(1L);
        booking.setUser(anotherUser);
        booking.setStatus("BOOKED");

        when(authentication.getName()).thenReturn("user@example.com");
        when(userRepository.findByEmail("user@example.com")).thenReturn(Optional.of(testUser));
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));

        assertThrows(RuntimeException.class, () -> {
            bookingService.cancelBooking(1L, authentication);
        });
    }

    @Test
    void testGetMyBookings_Success() {
        Booking booking = new Booking();
        booking.setId(1L);
        booking.setSeatCount(2);
        booking.setTotalPrice(5000);
        booking.setStatus("BOOKED");
        booking.setBookingDate(LocalDateTime.now());
        booking.setTravelDate(LocalDate.now());
        booking.setUser(testUser);
        booking.setFlight(testFlight);

        when(authentication.getName()).thenReturn("user@example.com");
        when(userRepository.findByEmail("user@example.com")).thenReturn(Optional.of(testUser));
        when(bookingRepository.findByUser(testUser)).thenReturn(List.of(booking));

        List<BookingResponse> responses = bookingService.getMyBookings(authentication);
        assertEquals(1, responses.size());
        assertEquals("BOOKED", responses.get(0).getStatus());
    }


    @Test
    void testBookFlight_InsufficientSeats() {
        when(authentication.getName()).thenReturn("user@example.com");
        when(userRepository.findByEmail("user@example.com")).thenReturn(Optional.of(testUser));
        when(flightRepository.findById(1L)).thenReturn(Optional.of(testFlight));

        List<Seat> fewSeats = Arrays.asList(new Seat()); // only 1 seat, but 2 requested
        when(seatRepository.findByFlightAndIsBookedFalse(testFlight)).thenReturn(fewSeats);

        assertThrows(RuntimeException.class, () -> {
            bookingService.bookFlight(bookingRequest, authentication);
        });
    }



    @Test
    void testCancelBooking_AlreadyCancelled() {
        Booking booking = new Booking();
        booking.setId(1L);
        booking.setStatus("CANCELLED");
        booking.setUser(testUser);

        when(authentication.getName()).thenReturn("user@example.com");
        when(userRepository.findByEmail("user@example.com")).thenReturn(Optional.of(testUser));
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));

        assertThrows(RuntimeException.class, () -> {
            bookingService.cancelBooking(1L, authentication);
        });
    }

    @Test
    void testGetAllBookings_ReturnsList() {
        Booking booking = new Booking();
        booking.setId(1L);
        booking.setUser(testUser);
        booking.setFlight(testFlight);
        booking.setSeatCount(1);
        booking.setStatus("BOOKED");
        booking.setBookingDate(LocalDateTime.now());
        booking.setTravelDate(LocalDate.now());

        when(bookingRepository.findAll()).thenReturn(List.of(booking));

        List<BookingResponse> allBookings = bookingService.getAllBookings();
        assertEquals(1, allBookings.size());
        assertEquals("BOOKED", allBookings.get(0).getStatus());
    }

}

