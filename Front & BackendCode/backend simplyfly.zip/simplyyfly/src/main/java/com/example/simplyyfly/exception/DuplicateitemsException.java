package com.example.simplyyfly.exception;

public class DuplicateitemsException extends RuntimeException {
    public DuplicateitemsException(String message) {
        super(message);
    }
}
