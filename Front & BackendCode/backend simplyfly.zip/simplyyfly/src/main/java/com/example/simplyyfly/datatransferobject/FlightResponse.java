package com.example.simplyyfly.datatransferobject;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class FlightResponse {
    private Long id;
    private String flightid;
    private String flight;
    private String origin;
    private String destination;
    private int totalSeats;
    private double fare;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
}