package com.example.simplyyfly.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.simplyyfly.Items.Flight;
import com.example.simplyyfly.Items.Route;
import com.example.simplyyfly.Items.User;

import java.time.LocalDateTime;
import java.util.List;

public interface FlightRepository extends JpaRepository<Flight, Long> {
	
    List<Flight> findByRouteAndDepartureTimeBetween(Route route, LocalDateTime start, LocalDateTime end);
    List<Flight> findByRoute_OriginAndRoute_DestinationAndDepartureTimeBetween(
    	    String origin, String destination, LocalDateTime start, LocalDateTime end);
List<Flight> findByFlightOwner(User owner);
}
