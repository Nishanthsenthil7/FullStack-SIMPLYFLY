package com.example.simplyyfly.service;

import com.example.simplyyfly.Items.Route;
import com.example.simplyyfly.Repo.RouteRepository;
import com.example.simplyyfly.datatransferobject.AddRouteRequest;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RouteServiceImpl implements RouteService {

    private final RouteRepository routeRepository;

    @Override
    public void addRoute(AddRouteRequest request) {
        if (routeRepository.existsByOriginAndDestination(request.getOrigin(), request.getDestination())) {
            throw new IllegalArgumentException("Route already exists");
        }
        Route route = new Route();
        route.setOrigin(request.getOrigin());
        route.setDestination(request.getDestination());
        route.setDistanceInKm(request.getDistanceInKm());
        routeRepository.save(route);
    }

    @Override
    public List<AddRouteRequest> getAllRoutes() {
        return routeRepository.findAll().stream().map(route -> {
            AddRouteRequest dto = new AddRouteRequest();
            dto.setOrigin(route.getOrigin());
            dto.setDestination(route.getDestination());
            dto.setDistanceInKm(route.getDistanceInKm());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public void updateRoute(Long id, AddRouteRequest request) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Route not found"));
        route.setOrigin(request.getOrigin());
        route.setDestination(request.getDestination());
        route.setDistanceInKm(request.getDistanceInKm());
        routeRepository.save(route);
    }
}