package com.example.simplyyfly.controller;

import com.example.simplyyfly.Items.User;
import com.example.simplyyfly.Items.Booking;
import com.example.simplyyfly.service.UserService;
import com.example.simplyyfly.Repo.BookingRepository;
import com.example.simplyyfly.datatransferobject.BookingDTO;
import com.example.simplyyfly.datatransferobject.FlightDTO;
import com.example.simplyyfly.datatransferobject.UserDetailsResponse;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Tag(name = "User Management", description = "to verify roles")
public class UserController {

    private final UserService userService;
    private final BookingRepository bookingRepository;

    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<User>> getAllUsers() {
        log.info("GET /api/users - admin view all");
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        log.info("GET /api/users/{} - admin fetch user", id);
        return ResponseEntity.ok(userService.getUserById(id));
    }

    @GetMapping("/{id}/details")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<UserDetailsResponse> getUserDetails(@PathVariable Long id) {
        log.info("GET /api/users/{}/details - admin fetch full user data", id);
        User user = userService.getUserById(id);
        List<Booking> bookings = bookingRepository.findByUser(user);

        List<BookingDTO> bookingDTOs = bookings.stream().map(b -> new BookingDTO(
            b.getId(),
            b.getStatus(),
            b.getBookingDate(),
            new FlightDTO(b.getFlight().getFlight()) // ✅ mapped to DTO
        )).collect(Collectors.toList());

        UserDetailsResponse response = new UserDetailsResponse(
            user.getId(),
            user.getName(),
            user.getEmail(),
            user.getContactNumber(),
            user.getAddress(),
            user.getRole().name(),
            bookingDTOs
        );

        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        log.info("DELETE /api/users/{} - admin delete user", id);
        try {
            userService.deleteUser(id);
            return ResponseEntity.ok(Map.of("message", "User deleted successfully"));
        } catch (RuntimeException e) {
            log.warn("User delete failed: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    @GetMapping("/me")
    @PreAuthorize("isAuthenticated()")
    
    public ResponseEntity<User> getCurrentUser(Authentication authentication) {
        String email = authentication.getName();
        log.info("GET /api/users/me - user: {}", email);
        return ResponseEntity.ok(userService.getCurrentUser(email));
    }

    @PutMapping("/me")
    @PreAuthorize("isAuthenticated()")
    
    public ResponseEntity<User> updateCurrentUser(@Valid @RequestBody User updatedUser,
                                                  Authentication authentication) {
        String email = authentication.getName();
        log.info("PUT /api/users/me - updating user: {}", email);
        return ResponseEntity.ok(userService.updateCurrentUser(email, updatedUser));
    }
}
