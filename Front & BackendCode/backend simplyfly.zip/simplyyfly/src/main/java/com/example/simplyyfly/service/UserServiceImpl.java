package com.example.simplyyfly.service;

import com.example.simplyyfly.Items.Role;
import com.example.simplyyfly.Items.User;
import com.example.simplyyfly.Items.Booking;
import com.example.simplyyfly.Repo.BookingRepository;
import com.example.simplyyfly.Repo.UserRepository;
import com.example.simplyyfly.datatransferobject.AuthResponse;
import com.example.simplyyfly.datatransferobject.LoginRequest;
import com.example.simplyyfly.datatransferobject.RegisterRequest;
import com.example.simplyyfly.security.JwtTokenUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final BookingRepository bookingRepository; // ✅ Added this
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenUtil jwtTokenUtil;

    // ✅ Register a new user
    @Override
    public AuthResponse registerUser(RegisterRequest request) {
        log.info("Attempting to register user with email: {}", request.getEmail());

        try {
            if (userRepository.existsByEmail(request.getEmail())) {
                log.warn("Registration failed - email already in use: {}", request.getEmail());
                throw new RuntimeException("use some other email");
            }

            User user = new User();
            user.setName(request.getName());
            user.setEmail(request.getEmail());
            user.setPassword(passwordEncoder.encode(request.getPassword()));
            user.setContactNumber(request.getContactNumber());
            user.setAddress(request.getAddress());
            user.setRole(request.getRole() != null ? request.getRole() : Role.USER);

            userRepository.save(user);
            log.info("User registered successfully: {}", user.getEmail());

            String token = jwtTokenUtil.generateToken(user.getEmail(), user.getRole().name());

            // ✅ Normalize FLIGHT_OWNER to OWNER in response
            String roleToSend = (user.getRole() == Role.FLIGHT_OWNER || user.getRole() == Role.OWNER)
                ? "OWNER"
                : user.getRole().name();

            return new AuthResponse(token, roleToSend, user.getName(), "User registered successfully");

        } catch (Exception e) {
            log.error("Registration failed for email: {}. Reason: {}", request.getEmail(), e.getMessage(), e);
            throw new RuntimeException("Registration failed. Please try again.");
        }
    }

    // ✅ Authenticate user login
    @Override
    public AuthResponse authenticateUser(LoginRequest request) {
        log.info("Authenticating user: {}", request.getEmail());

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email or password"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            log.warn("Invalid login attempt for user: {}", request.getEmail());
            throw new RuntimeException("Invalid email or password");
        }

        String token = jwtTokenUtil.generateToken(user.getEmail(), user.getRole().name());

        // ✅ Normalize FLIGHT_OWNER to OWNER in response
        String roleToSend = (user.getRole() == Role.FLIGHT_OWNER || user.getRole() == Role.OWNER)
            ? "OWNER"
            : user.getRole().name();

        log.info("Login successful for user: {}", request.getEmail());
        return new AuthResponse(token, roleToSend, user.getName(), "Login successful");
    }

    // ✅ Get user profile by email
    @Override
    public User getCurrentUser(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    // ✅ Update user profile
    @Override
    public User updateCurrentUser(String email, User updatedUser) {
        User user = getCurrentUser(email);
        user.setName(updatedUser.getName());
        user.setAddress(updatedUser.getAddress());
        user.setContactNumber(updatedUser.getContactNumber());
        return userRepository.save(user);
    }

    // ✅ Admin functionalities
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    // ✅ Updated: Prevent deletion if user has bookings
    @Override
    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<Booking> userBookings = bookingRepository.findByUser(user);
        if (!userBookings.isEmpty()) {
            throw new RuntimeException("Cannot delete user with existing bookings");
        }

        userRepository.deleteById(id);
    }
}
