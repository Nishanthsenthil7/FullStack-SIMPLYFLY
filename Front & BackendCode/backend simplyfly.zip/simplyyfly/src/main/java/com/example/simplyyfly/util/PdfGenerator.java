package com.example.simplyyfly.util;

import com.example.simplyyfly.Items.Booking;
import com.example.simplyyfly.Items.Route;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.*;

import java.io.ByteArrayOutputStream;

public class PdfGenerator {

    public static byte[] generateBookingPdf(Booking booking) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdfDoc = new PdfDocument(writer);
        Document document = new Document(pdfDoc, PageSize.A4);
        document.setMargins(30, 30, 30, 30);

        // ✅ Add Logo
        try {
            String path = "src/main/resources/static/simplyfly-logo.png.png";
            ImageData imageData = ImageDataFactory.create(path);
            Image logo = new Image(imageData);
            logo.setWidth(100);
            logo.setHeight(100);
            logo.setMarginBottom(10);
            document.add(logo);
        } catch (Exception e) {
            System.out.println("Logo not found: " + e.getMessage());
        }

        // ✅ Welcome Title
        Paragraph welcome = new Paragraph("🛫 Welcome to SimplyFly!")
                .setBold()
                .setFontSize(18)
                .setFontColor(ColorConstants.BLUE);
        document.add(welcome);

        String passengerName = (booking.getUser() != null && booking.getUser().getName() != null)
                ? booking.getUser().getName()
                : "Unknown Passenger";

        Paragraph sub = new Paragraph("Passenger: " + passengerName)
                .setFontSize(12);
        document.add(sub);

        document.add(new Paragraph("\n"));

        // ✅ Confirmation Heading
        Paragraph confirm = new Paragraph("✅ Booking Confirmation")
                .setFontSize(16)
                .setBold()
                .setFontColor(ColorConstants.BLACK);
        document.add(confirm);

        document.add(new Paragraph("\n"));

        // ✅ Booking Table
        float[] columnWidths = {200f, 300f};
        Table table = new Table(columnWidths);

        table.addCell(getHeaderCell("Booking ID"));
        table.addCell(getValueCell(String.valueOf(booking.getId())));

        // ✅ Flight Name or fallback
        String flightName = "Air Asia";
        if (booking.getFlight() != null && booking.getFlight().getFlight() != null) {
            flightName = booking.getFlight().getFlight();
        }
        table.addCell(getHeaderCell("Flight Name"));
        table.addCell(getValueCell(flightName));

        // ✅ Route: origin and destination fallback
        String origin = "string";
        String destination = "string";
        if (booking.getFlight() != null && booking.getFlight().getRoute() != null) {
            Route route = booking.getFlight().getRoute();
            origin = route.getOrigin() != null ? route.getOrigin() : "string";
            destination = route.getDestination() != null ? route.getDestination() : "string";
        }
        table.addCell(getHeaderCell("Route"));
        table.addCell(getValueCell(origin + " → " + destination));

        table.addCell(getHeaderCell("Travel Date"));
        table.addCell(getValueCell(String.valueOf(booking.getTravelDate())));

        table.addCell(getHeaderCell("Total Seats"));
        table.addCell(getValueCell(String.valueOf(booking.getSeatCount())));

        table.addCell(getHeaderCell("Total Price"));
        table.addCell(getValueCell("₹" + booking.getTotalPrice()));

        table.addCell(getHeaderCell("Status"));
        table.addCell(getValueCell(booking.getStatus() != null ? booking.getStatus() : "UNKNOWN"));

        document.add(table);
        document.add(new Paragraph("\n"));

        // ✅ Thank You Message
        Paragraph thanks = new Paragraph("🎉 Thank you for booking with SimplyFly!\nWe wish you a safe and pleasant journey.")
                .setFontSize(12)
                .setFontColor(ColorConstants.GRAY);
        document.add(thanks);

        document.close();
        return out.toByteArray();
    }

    private static Cell getHeaderCell(String text) {
        return new Cell()
                .add(new Paragraph(text))
                .setBold()
                .setBackgroundColor(ColorConstants.LIGHT_GRAY)
                .setBorder(new SolidBorder(ColorConstants.GRAY, 0.5f));
    }

    private static Cell getValueCell(String text) {
        return new Cell()
                .add(new Paragraph(text))
                .setBorder(new SolidBorder(ColorConstants.LIGHT_GRAY, 0.5f));
    }
}
