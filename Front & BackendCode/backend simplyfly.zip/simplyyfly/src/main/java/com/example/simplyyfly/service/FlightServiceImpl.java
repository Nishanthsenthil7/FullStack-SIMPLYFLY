package com.example.simplyyfly.service;

import com.example.simplyyfly.Items.Flight;
import com.example.simplyyfly.Items.Route;
import com.example.simplyyfly.Items.User;
import com.example.simplyyfly.Repo.FlightRepository;
import com.example.simplyyfly.Repo.RouteRepository;
import com.example.simplyyfly.Repo.UserRepository;
import com.example.simplyyfly.datatransferobject.*;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FlightServiceImpl implements FlightService {

    private final FlightRepository flightRepository;
    private final RouteRepository routeRepository;
    private final UserRepository userRepository;

    @Override
    public void addFlight(AddFlightRequest request, Authentication authentication) {
        Flight flight = new Flight();
        Route route = routeRepository.findById(request.getRouteId()).orElseThrow();
        User user = userRepository.findByEmail(authentication.getName()).orElseThrow();

        flight.setFlightid(request.getFlightid());
        flight.setFlight(request.getFlight());
        flight.setRoute(route);
        flight.setTotalSeats(request.getTotalSeats());
        flight.setFare(request.getFare());
        flight.setDepartureTime(request.getDepartureTime());
        flight.setArrivalTime(request.getArrivalTime());
        flight.setFlightOwner(user);

        flightRepository.save(flight);
    }

    @Override
    public void updateFlight(Long id, AddFlightRequest request, Authentication authentication) {
        Flight flight = flightRepository.findById(id).orElseThrow();
        Route route = routeRepository.findById(request.getRouteId()).orElseThrow();

        flight.setFlightid(request.getFlightid());
        flight.setFlight(request.getFlight());
        flight.setRoute(route);
        flight.setTotalSeats(request.getTotalSeats());
        flight.setFare(request.getFare());
        flight.setDepartureTime(request.getDepartureTime());
        flight.setArrivalTime(request.getArrivalTime());

        flightRepository.save(flight);
    }

    @Override
    public void deleteFlight(Long id) {
        flightRepository.deleteById(id);
    }

    @Override
    public List<FlightResponse> getAllFlights() {
        return flightRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public FlightResponse getFlightById(Long id) {
        return mapToDto(flightRepository.findById(id).orElseThrow());
    }

    // ✅ Rewritten method: Search using origin, destination, and departureDate
    @Override
    public List<FlightResponse> searchFlights(FlightSearchRequest request) {
        String origin = request.getOrigin().trim().toLowerCase();
        String destination = request.getDestination().trim().toLowerCase();
        LocalDate departureDate = request.getDepartureDate();

        return flightRepository.findAll().stream()
                .filter(flight -> flight.getRoute().getOrigin().toLowerCase().equals(origin))
                .filter(flight -> flight.getRoute().getDestination().toLowerCase().equals(destination))
                .filter(flight -> flight.getDepartureTime().toLocalDate().equals(departureDate))
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<FlightResponse> getFlightsByOwner(String email) {
        User owner = userRepository.findByEmail(email).orElseThrow();
        return flightRepository.findByFlightOwner(owner).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private FlightResponse mapToDto(Flight flight) {
        FlightResponse response = new FlightResponse();
        response.setId(flight.getId());
        response.setFlightid(flight.getFlightid());
        response.setFlight(flight.getFlight());
        response.setOrigin(flight.getRoute().getOrigin());
        response.setDestination(flight.getRoute().getDestination());
        response.setTotalSeats(flight.getTotalSeats());
        response.setFare(flight.getFare());
        response.setDepartureTime(flight.getDepartureTime());
        response.setArrivalTime(flight.getArrivalTime());
        return response;
    }
}
