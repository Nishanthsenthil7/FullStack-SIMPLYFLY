package com.example.simplyyfly.datatransferobject;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingResponse {
    private Long bookingId;
    private String flightNumber;
    private String flightName;
    private String origin;
    private String destination;
    private int seatCount;
    private double totalPrice;
    private String status;
    private LocalDateTime bookingDate;
    private LocalDate travelDate;
    private boolean ownerApproved;
    private boolean refundProcessed;

}
