package com.example.simplyyfly.Items;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "flights")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = {"flightOwner", "route"})
@EqualsAndHashCode(of = "id")
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String flightid; // ✅ NEW FIELD for flight ID (e.g., "SF123")

    private String flight; // Optional: display name or airline name

    @ManyToOne
    @JoinColumn(name = "route_id")
    @JsonIgnore
    private Route route;

    private int totalSeats;
    private double fare;

    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;

    @ManyToOne
    @JoinColumn(name = "flightowner_id")
    @JsonIgnore
    private User flightOwner; // ✅ RENAMED from Owner → flightOwner
}
