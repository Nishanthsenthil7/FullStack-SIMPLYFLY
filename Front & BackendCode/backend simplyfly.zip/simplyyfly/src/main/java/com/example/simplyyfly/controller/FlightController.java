package com.example.simplyyfly.controller;

import com.example.simplyyfly.datatransferobject.AddFlightRequest;
import com.example.simplyyfly.datatransferobject.FlightResponse;
import com.example.simplyyfly.datatransferobject.FlightSearchRequest;
import com.example.simplyyfly.service.FlightService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/flights")
@RequiredArgsConstructor
@Tag(name = "Flight Management", description = "Create, update, and manage flights")
public class FlightController {

    private final FlightService flightService;

    // ✅ POST search flights (keep this ABOVE /{id} to avoid conflict)
    @PostMapping("/search")
    public ResponseEntity<List<FlightResponse>> searchFlights(@RequestBody FlightSearchRequest request) {
        log.info("POST /api/flights/search called");
        List<FlightResponse> flights = flightService.searchFlights(request);
        return ResponseEntity.ok(flights);
    }

    // ✅ GET all flights created by currently logged-in OWNER
    @GetMapping("/owner")
    @PreAuthorize("hasAuthority('FLIGHT_OWNER')")
    public ResponseEntity<List<FlightResponse>> getFlightsByOwner(Authentication authentication) {
        String email = authentication.getName();
        log.info("GET /api/flights/owner called by {}", email);
        List<FlightResponse> flights = flightService.getFlightsByOwner(email);
        return ResponseEntity.ok(flights);
    }

    // ✅ GET flight by ID (MUST be after all fixed routes like /search)
    @GetMapping("/{id}")
    public ResponseEntity<FlightResponse> getFlightById(@PathVariable Long id) {
        log.info("GET /api/flights/{} called", id);
        FlightResponse response = flightService.getFlightById(id);
        return ResponseEntity.ok(response);
    }

    // ✅ POST create a flight (ADMIN or OWNER)
    @PostMapping
    @PreAuthorize("hasAnyAuthority('ADMIN', 'FLIGHT_OWNER')")
    public ResponseEntity<Map<String, String>> addFlight(@RequestBody AddFlightRequest request,
                                                         Authentication authentication) {
        log.info("POST /api/flights called by {}", authentication.getName());
        flightService.addFlight(request, authentication);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Flight added successfully");
        return ResponseEntity.ok(response);
    }

    // ✅ PUT update a flight (ADMIN or OWNER)
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN', 'FLIGHT_OWNER')")
    public ResponseEntity<Map<String, String>> updateFlight(@PathVariable Long id,
                                                            @RequestBody AddFlightRequest request,
                                                            Authentication authentication) {
        log.info("PUT /api/flights/{} called by {}", id, authentication.getName());
        flightService.updateFlight(id, request, authentication);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Flight updated successfully");
        return ResponseEntity.ok(response);
    }

    // ✅ DELETE flight (ADMIN or OWNER)
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN', 'FLIGHT_OWNER')")
    public ResponseEntity<Map<String, String>> deleteFlight(@PathVariable Long id) {
        log.info("DELETE /api/flights/{} called", id);
        flightService.deleteFlight(id);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Flight deleted successfully");
        return ResponseEntity.ok(response);
    }
}
