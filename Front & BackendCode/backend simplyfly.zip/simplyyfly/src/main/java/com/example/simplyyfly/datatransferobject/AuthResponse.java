package com.example.simplyyfly.datatransferobject;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AuthResponse {
    private String token;
    private String role;
    private String username;
    private String message;

    public AuthResponse(String token, String role, String username, String message) {
        this.token = token;
        this.role = role;
        this.username = username;
        this.message = message;
    }
}
