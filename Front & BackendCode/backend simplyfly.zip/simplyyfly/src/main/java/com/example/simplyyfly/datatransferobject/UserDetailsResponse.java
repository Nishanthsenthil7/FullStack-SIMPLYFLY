package com.example.simplyyfly.datatransferobject;
import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;

@Data
@AllArgsConstructor
public class UserDetailsResponse {
    private Long id;
    private String name;
    private String email;
    private String contactNumber;
    private String address;
    private String role; // Changed from Role enum to String for clarity in JSON
    private List<BookingDTO> bookings;
}
