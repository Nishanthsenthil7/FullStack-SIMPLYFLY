package com.example.simplyyfly.service;

import com.example.simplyyfly.Items.User;
import com.example.simplyyfly.datatransferobject.AuthResponse;
import com.example.simplyyfly.datatransferobject.LoginRequest;
import com.example.simplyyfly.datatransferobject.RegisterRequest;

import java.util.List;

public interface UserService {

    // 🔐 Auth
    AuthResponse registerUser(RegisterRequest request);
    AuthResponse authenticateUser(LoginRequest request);

    // 👤 User management
    User getCurrentUser(String email);
    User updateCurrentUser(String email, User updatedUser);

    // 🛠️ Admin management
    List<User> getAllUsers();
    User getUserById(Long id);
    void deleteUser(Long id);
}
