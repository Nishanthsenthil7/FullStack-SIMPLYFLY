package com.example.simplyyfly.controller;

import com.example.simplyyfly.datatransferobject.AddRouteRequest;
import com.example.simplyyfly.service.RouteService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/routes")
@RequiredArgsConstructor
@Tag(name = "Route Management", description = "Manage air routes and route availability")
public class RouteController {

    private final RouteService routeService;

    @PostMapping
    @PreAuthorize("hasAuthority('FLIGHT_OWNER')")
    public ResponseEntity<Map<String, String>> addRoute(@RequestBody AddRouteRequest request) {
        routeService.addRoute(request);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Route added successfully");
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<List<AddRouteRequest>> getAllRoutes() {
        log.info("GET /api/routes - Fetching all routes");
        return ResponseEntity.ok(routeService.getAllRoutes());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('FLIGHT_OWNER')")
    
    public ResponseEntity<Map<String, String>> updateRoute(@PathVariable Long id, @RequestBody AddRouteRequest request) {
        routeService.updateRoute(id, request);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Route updated successfully");
        return ResponseEntity.ok(response);
    }
}
