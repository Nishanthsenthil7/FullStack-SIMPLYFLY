// BookingController.java
package com.example.simplyyfly.controller;

import com.example.simplyyfly.datatransferobject.BookingRequest;
import com.example.simplyyfly.datatransferobject.BookingResponse;
import com.example.simplyyfly.service.BookingService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@Tag(name = "Booking Management", description = "Book, cancel, and view flight tickets")
public class BookingController {

    private final BookingService bookingService;

    @PostMapping
    @PreAuthorize("hasAuthority('USER')")
    public ResponseEntity<BookingResponse> bookFlight(@RequestBody BookingRequest request,
                                                      Authentication authentication) {
        return ResponseEntity.ok(bookingService.bookFlight(request, authentication));
    }

    @GetMapping("/my")
    @PreAuthorize("hasAuthority('USER')")
    public ResponseEntity<List<BookingResponse>> getMyBookings(Authentication authentication) {
        return ResponseEntity.ok(bookingService.getMyBookings(authentication));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('USER')")
    public ResponseEntity<String> cancelBooking(@PathVariable Long id, Authentication authentication) {
        return ResponseEntity.ok(bookingService.cancelBooking(id, authentication));
    }

    @GetMapping("/all")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<BookingResponse>> getAllBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }

    @GetMapping("/{bookingId}/ticket")
    @PreAuthorize("hasAuthority('USER')")
    public ResponseEntity<byte[]> downloadTicket(@PathVariable Long bookingId) {
        byte[] pdfBytes = bookingService.generatePdfForBooking(bookingId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=booking-" + bookingId + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }

    @GetMapping("/owner")
    @PreAuthorize("hasAuthority('FLIGHT_OWNER')")
    public ResponseEntity<List<BookingResponse>> getBookingsForOwner(Authentication authentication) {
        return ResponseEntity.ok(bookingService.getBookingsForMyFlights(authentication.getName()));
    }

    @PutMapping("/owner/approve-refund/{bookingId}")
    @PreAuthorize("hasAuthority('FLIGHT_OWNER')")
    public ResponseEntity<String> approveRefund(@PathVariable Long bookingId, Authentication auth) {
        return ResponseEntity.ok(bookingService.approveCancelledBooking(bookingId, auth.getName()));
    }
}