package com.example.simplyyfly.controller;

import com.example.simplyyfly.Items.Flight;
import com.example.simplyyfly.Items.Seat;
import com.example.simplyyfly.Repo.FlightRepository;
import com.example.simplyyfly.Repo.SeatRepository;
import com.example.simplyyfly.datatransferobject.SeatDTO;
import com.example.simplyyfly.exception.ValueNotFoundException;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/seats")
@RequiredArgsConstructor
@Tag(name = "Seat Management", description = "Manage seat availability and selection")

public class SeatController {

    private final SeatRepository seatRepository;
    private final FlightRepository flightRepository;
    // 🔍 View seats by Flight ID
    @GetMapping("/flight/{flightId}")
    @PreAuthorize("hasAuthority('ADMIN')")
    
    public ResponseEntity<List<SeatDTO>> getSeatsByFlight(@PathVariable Long flightId) {
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new ValueNotFoundException("Flight not found"));

        List<SeatDTO> seatDTOs = seatRepository.findByFlightAndIsBookedFalse(flight).stream()
                .map(seat -> new SeatDTO(
                        seat.getId(),
                        seat.getSeatNumber(),
                        seat.isBooked()
                )).collect(Collectors.toList());

        return ResponseEntity.ok(seatDTOs);
    }
    
}

