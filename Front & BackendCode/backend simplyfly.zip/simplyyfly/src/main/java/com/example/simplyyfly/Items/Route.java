package com.example.simplyyfly.Items;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "routes")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Route {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String origin;
    private String destination;

    private int distanceInKm; // ✅ changed from String to int

    private String duration; // Optional: can be removed if not used
}
