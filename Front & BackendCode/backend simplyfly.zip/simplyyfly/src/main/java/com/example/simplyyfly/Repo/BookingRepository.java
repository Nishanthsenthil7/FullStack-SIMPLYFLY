package com.example.simplyyfly.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.simplyyfly.Items.Booking;
import com.example.simplyyfly.Items.User;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUser(User user);

    // ✅ Add this method to fetch bookings by flight owner
    @Query("SELECT b FROM Booking b WHERE b.flight.flightOwner = :owner")
    List<Booking> findByFlightOwner(@Param("owner") User owner);
}
