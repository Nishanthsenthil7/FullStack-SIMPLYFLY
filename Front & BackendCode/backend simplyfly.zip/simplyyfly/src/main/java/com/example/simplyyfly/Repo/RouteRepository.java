package com.example.simplyyfly.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.simplyyfly.Items.Route;

public interface RouteRepository extends JpaRepository<Route, Long> {
    boolean existsByOriginAndDestination(String origin, String destination);
}