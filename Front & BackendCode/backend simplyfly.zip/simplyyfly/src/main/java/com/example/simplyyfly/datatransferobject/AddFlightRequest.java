package com.example.simplyyfly.datatransferobject;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AddFlightRequest {
    private String flightid;
    private String flight;
    private Long routeId;
    private int totalSeats;
    private double fare;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
}