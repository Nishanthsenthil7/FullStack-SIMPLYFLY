// BookingService.java
package com.example.simplyyfly.service;

import org.springframework.security.core.Authentication;

import com.example.simplyyfly.datatransferobject.BookingRequest;
import com.example.simplyyfly.datatransferobject.BookingResponse;

import java.util.List;

public interface BookingService {
    BookingResponse bookFlight(BookingRequest request, Authentication authentication);
    List<BookingResponse> getMyBookings(Authentication authentication);
    String cancelBooking(Long bookingId, Authentication authentication);
    List<BookingResponse> getAllBookings();
    byte[] generatePdfForBooking(Long bookingId);
    List<BookingResponse> getBookingsForMyFlights(String ownerEmail);
    String approveCancelledBooking(Long bookingId, String ownerEmail);
}