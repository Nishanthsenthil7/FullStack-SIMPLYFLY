package com.example.simplyyfly.service;

import java.util.List;

import com.example.simplyyfly.datatransferobject.AddRouteRequest;

public interface RouteService {
    void addRoute(AddRouteRequest request);
    List<AddRouteRequest> getAllRoutes();
    void updateRoute(Long id, AddRouteRequest request);
}