package com.example.simplyyfly.Items;

public enum Role {
	 USER,
	 ADMIN,
	 OWNER,        
	 FLIGHT_OWNER
}
