package com.example.simplyyfly.datatransferobject;
import lombok.Data;

@Data
public class AddRouteRequest {
    private String origin;
    private String destination;
    private int distanceInKm;
}
