package com.example.simplyyfly.service;

import org.springframework.security.core.Authentication;

import com.example.simplyyfly.datatransferobject.*;

import java.util.List;

public interface FlightService {
    void addFlight(AddFlightRequest request, Authentication authentication);
    void updateFlight(Long id, AddFlightRequest request, Authentication authentication);
    void deleteFlight(Long id);
    List<FlightResponse> getAllFlights();
    FlightResponse getFlightById(Long id);
    List<FlightResponse> searchFlights(FlightSearchRequest request);
    List<FlightResponse> getFlightsByOwner(String email);
}