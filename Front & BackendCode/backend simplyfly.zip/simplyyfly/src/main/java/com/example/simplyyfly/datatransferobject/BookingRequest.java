package com.example.simplyyfly.datatransferobject;
import lombok.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingRequest {
    private Long flightId;
    private int seatCount;
    private LocalDate travelDate;
}
