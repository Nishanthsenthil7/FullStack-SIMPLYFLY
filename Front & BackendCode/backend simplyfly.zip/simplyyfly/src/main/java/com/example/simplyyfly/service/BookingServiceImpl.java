package com.example.simplyyfly.service;

import com.example.simplyyfly.Items.*;
import com.example.simplyyfly.Repo.*;
import com.example.simplyyfly.datatransferobject.BookingRequest;
import com.example.simplyyfly.datatransferobject.BookingResponse;
import com.example.simplyyfly.util.PdfGenerator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final SeatRepository seatRepository;
    private final UserRepository userRepository;
    private final FlightRepository flightRepository;
    private final EmailService emailService;

    @Override
    public BookingResponse bookFlight(BookingRequest request, Authentication authentication) {
        String userEmail = authentication.getName();
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        Flight flight = flightRepository.findById(request.getFlightId()).orElseThrow();

        List<Seat> availableSeats = seatRepository.findByFlightAndIsBookedFalse(flight);
        if (availableSeats.size() < request.getSeatCount()) {
            throw new RuntimeException("Not enough seats available");
        }

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setFlight(flight);
        booking.setBookingDate(LocalDateTime.now());
        booking.setTravelDate(request.getTravelDate());
        booking.setSeatCount(request.getSeatCount());
        booking.setTotalPrice(flight.getFare() * request.getSeatCount());
        booking.setStatus("BOOKED");
        booking.setOwnerApproved(false);
        booking.setRefundProcessed(false);

        Booking savedBooking = bookingRepository.save(booking);

        List<Seat> seatsToBook = availableSeats.subList(0, request.getSeatCount());
        for (Seat seat : seatsToBook) {
            seat.setBooked(true);
            seat.setBooking(savedBooking);
        }
        seatRepository.saveAll(seatsToBook);

        try {
            byte[] pdf = PdfGenerator.generateBookingPdf(savedBooking);
            emailService.sendBookingPdf(user.getEmail(), pdf, "booking-" + savedBooking.getId() + ".pdf");
        } catch (Exception e) {
            log.error("Email sending failed", e);
        }

        return mapToResponse(savedBooking);
    }

    @Override
    public String cancelBooking(Long bookingId, Authentication authentication) {
        String userEmail = authentication.getName();
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        Booking booking = bookingRepository.findById(bookingId).orElseThrow();

        if (!booking.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("You are not allowed to cancel this booking");
        }

        if (!"BOOKED".equals(booking.getStatus())) {
            throw new RuntimeException("Only booked tickets can be cancelled");
        }

        booking.setStatus("CANCELLED");
        booking.setOwnerApproved(false);
        booking.setRefundProcessed(false);
        bookingRepository.save(booking);

        List<Seat> seats = seatRepository.findByBookingId(bookingId);
        for (Seat seat : seats) {
            seat.setBooked(false);
            seat.setBooking(null);
        }
        seatRepository.saveAll(seats);

        return "Booking cancelled successfully.";
    }

    @Override
    public String approveCancelledBooking(Long bookingId, String ownerEmail) {
        Booking booking = bookingRepository.findById(bookingId).orElseThrow();

        if (!booking.getFlight().getFlightOwner().getEmail().equals(ownerEmail)) { // ✅ Fixed method
            throw new RuntimeException("Unauthorized: You don't own this flight");
        }

        if (!"CANCELLED".equals(booking.getStatus())) {
            throw new RuntimeException("Only cancelled bookings can be approved for refund");
        }

        booking.setOwnerApproved(true);
        booking.setRefundProcessed(true);
        bookingRepository.save(booking);

        return "Booking refund approved.";
    }

    @Override
    public List<BookingResponse> getMyBookings(Authentication authentication) {
        String userEmail = authentication.getName();
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        return bookingRepository.findByUser(user).stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Override
    public List<BookingResponse> getAllBookings() {
        return bookingRepository.findAll().stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Override
    public byte[] generatePdfForBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId).orElseThrow();
        return PdfGenerator.generateBookingPdf(booking);
    }

    @Override
    public List<BookingResponse> getBookingsForMyFlights(String ownerEmail) {
        User owner = userRepository.findByEmail(ownerEmail).orElseThrow();
        return bookingRepository.findByFlightOwner(owner).stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    private BookingResponse mapToResponse(Booking booking) {
        Flight flight = booking.getFlight();
        return new BookingResponse(
                booking.getId(),
                flight.getFlightid(),
                flight.getFlight(),
                flight.getRoute().getOrigin(),
                flight.getRoute().getDestination(),
                booking.getSeatCount(),
                booking.getTotalPrice(),
                booking.getStatus(),
                booking.getBookingDate(),
                booking.getTravelDate(),
                booking.isOwnerApproved(),
                booking.isRefundProcessed()
        );
    }
}
