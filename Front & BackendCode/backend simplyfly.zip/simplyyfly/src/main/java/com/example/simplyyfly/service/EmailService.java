package com.example.simplyyfly.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    public void sendBookingPdf(String to, byte[] pdfData, String filename) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setTo(to);
        helper.setSubject("📄 Your SimplyFly Booking PDF");
        helper.setText("Thank you for booking with SimplyFly! Your booking confirmation is attached.");

        helper.addAttachment(filename, new ByteArrayResource(pdfData));

        mailSender.send(message);
    }
}
