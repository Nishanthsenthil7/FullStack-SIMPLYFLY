package com.example.simplyyfly.controller;
import com.example.simplyyfly.datatransferobject.AuthResponse;
import com.example.simplyyfly.datatransferobject.LoginRequest;
import com.example.simplyyfly.datatransferobject.RegisterRequest;
import com.example.simplyyfly.service.UserService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication", description = "Handles  login credential")
public class AuthController {

    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@RequestBody RegisterRequest request) {
        log.info("POST /api/auth/register called for email: {}", request.getEmail());
        AuthResponse response = userService.registerUser(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        log.info("POST /api/auth/login called for email: {}", request.getEmail());
        AuthResponse response = userService.authenticateUser(request);
        return ResponseEntity.ok(response);
    }
}
