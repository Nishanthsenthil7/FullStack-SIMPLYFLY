import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RouteService {
  private apiUrl = 'http://localhost:8081/api/routes'; // ✅ Ensure CORS is enabled on backend

  constructor(private http: HttpClient) {}

  addRoute(routeData: any): Observable<any> {
    return this.http.post(this.apiUrl, routeData);
  }

  getAllRoutes(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }
}
