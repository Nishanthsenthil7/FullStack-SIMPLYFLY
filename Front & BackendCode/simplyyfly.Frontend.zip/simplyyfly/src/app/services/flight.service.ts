import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FlightService {
  private baseUrl = 'http://localhost:8081/api/flights';

  constructor(private http: HttpClient) {}

  // ✅ Search flights based on origin, destination, and date
  searchFlights(searchData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/search`, searchData);
  }

  // ✅ Get flight by ID (optional if needed for viewing details)
  getFlightById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  // ✅ Get flights created by the current flight owner (OWNER role)
  getFlightsByOwner(): Observable<any> {
    return this.http.get(`${this.baseUrl}/owner`);
  }

  // ✅ Add a new flight (for ADMIN/OWNER roles)
  addFlight(flightData: any): Observable<any> {
    return this.http.post(this.baseUrl, flightData);
  }

  // ✅ Update flight (for ADMIN/OWNER roles)
  updateFlight(id: number, flightData: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, flightData);
  }

  // ✅ Delete flight (for ADMIN/OWNER roles)
  deleteFlight(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}
