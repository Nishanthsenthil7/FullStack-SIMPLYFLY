import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OwnerService {
  private baseUrl = 'http://localhost:8081/api/flights'; // Handles flight-related endpoints
  private bookingUrl = 'http://localhost:8081/api/bookings'; // Handles bookings by owner

  constructor(private http: HttpClient) {}

  // ✅ Get all flights created by the logged-in flight owner
  getMyFlights(): Observable<any> {
    return this.http.get(`${this.baseUrl}/owner`);
  }

  // ✅ Get all bookings for flights created by the owner
  getBookingsForMyFlights(): Observable<any> {
    return this.http.get(`${this.bookingUrl}/owner`);
  }

  // ✅ Add a new flight (as owner or admin)
  addFlight(flightData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}`, flightData);
  }

  // (Optional) Delete a flight by ID
  deleteFlight(flightId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${flightId}`);
  }

  // (Optional) Update a flight
  updateFlight(flightId: number, flightData: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${flightId}`, flightData);
  }
}
