import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private baseUrl = 'http://localhost:8081/api/bookings';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }

  bookTicket(data: any): Observable<any> {
    return this.http.post(this.baseUrl, data, {
      headers: this.getAuthHeaders()
    });
  }

  getUserBookings(): Observable<any> {
    return this.http.get(`${this.baseUrl}/my`, {
      headers: this.getAuthHeaders()
    });
  }

  cancelBooking(bookingId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${bookingId}`, {
      headers: this.getAuthHeaders()
    });
  }

  downloadBookingPdf(bookingId: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/${bookingId}/ticket`, {
      headers: this.getAuthHeaders(),
      responseType: 'blob'
    });
  }

  getOwnerRefundRequests(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/owner/refunds`, {
      headers: this.getAuthHeaders()
    });
  }

  approveRefund(bookingId: number): Observable<any> {
    return this.http.put(`${this.baseUrl}/owner/approve-refund/${bookingId}`, {}, {
      headers: this.getAuthHeaders()
    });
  }

  getAllBookingsForAdmin(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/admin/all`, {
      headers: this.getAuthHeaders()
    });
  }
}
