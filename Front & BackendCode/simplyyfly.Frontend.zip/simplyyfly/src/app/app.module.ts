import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// ✅ Forms & HTTP
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'; // <-- Updated

// ✅ Routing & Common functionality
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

// ✅ Public components
import { InterfaceComponent } from './components/interface/interface.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';

// ✅ User dashboard components
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { UserHomeComponent } from './components/user-home/user-home.component';
import { BookTicketComponent } from './components/book-ticket/book-ticket.component';
import { SearchFlightsComponent } from './components/search-flights/search-flights.component';
import { ProfileComponent } from './components/profile/profile.component';
import { UserBookingsComponent } from './components/user-bookings/user-bookings.component';

// ✅ Admin & Owner dashboard components
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { OwnerDashboardComponent } from './components/owner-dashboard/owner-dashboard.component';

// ✅ Guards
import { AuthGuard } from './guards/auth.guard';
import { RoleGuard } from './guards/role.guard';

// ✅ Interceptor
import { TokenInterceptor } from './services/token-interceptor.service';
import { UserDetailsComponent } from './admin/user-details/user-details.component';
// <-- Make sure this path is correct

@NgModule({
  declarations: [
    AppComponent,
    InterfaceComponent,
    LoginComponent,
    RegisterComponent,
    UserDashboardComponent,
    UserHomeComponent,
    BookTicketComponent,
    SearchFlightsComponent,
    ProfileComponent,
    UserBookingsComponent,
    AdminDashboardComponent,
    OwnerDashboardComponent,
    UserDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    CommonModule
  ],
  providers: [
    AuthGuard,
    RoleGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
