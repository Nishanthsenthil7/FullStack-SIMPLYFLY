import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { InterfaceComponent } from './components/interface/interface.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { BookTicketComponent } from './components/book-ticket/book-ticket.component';
import { SearchFlightsComponent } from './components/search-flights/search-flights.component';
import { ProfileComponent } from './components/profile/profile.component';
import { UserBookingsComponent } from './components/user-bookings/user-bookings.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { OwnerDashboardComponent } from './components/owner-dashboard/owner-dashboard.component';
import { UserDetailsComponent } from './admin/user-details/user-details.component';



import { AuthGuard } from './guards/auth.guard';
import { RoleGuard } from './guards/role.guard';

const routes: Routes = [
  { path: '', component: InterfaceComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },

  {
    path: 'user-dashboard',
    component: UserDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { role: 'USER' },
    children: [
      { path: 'book-ticket', component: BookTicketComponent },
      { path: 'search-flights', component: SearchFlightsComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'bookings', component: UserBookingsComponent }
    ]
  },

  {
    path: 'admin-dashboard',
    component: AdminDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { role: 'ADMIN' }
  },
  {
    path: 'admin-dashboard/user/:id/details',
    component: UserDetailsComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { role: 'ADMIN' }
  },
  {
    path: 'owner-dashboard',
    component: OwnerDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { role: 'OWNER' }
  },

  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
