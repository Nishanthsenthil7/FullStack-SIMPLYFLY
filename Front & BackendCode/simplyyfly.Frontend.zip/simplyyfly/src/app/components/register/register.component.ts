import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      contactNumber: ['', Validators.required],
      address: ['', Validators.required],
      role: ['USER', Validators.required] // Default to USER
    });
  }

  onSubmit(): void {
    if (this.registerForm.valid) {
      this.authService.register(this.registerForm.value).subscribe({
        next: (response) => {
          // ✅ Save data to localStorage
          localStorage.setItem('token', response.token);
          localStorage.setItem('role', response.role);
          localStorage.setItem('username', this.registerForm.value.name);

          // ✅ Show success and route based on role
          this.successMessage = 'Registration successful! Redirecting...';

          setTimeout(() => {
            if (response.role === 'ADMIN') {
              this.router.navigate(['/admin-dashboard']);
            } else if (response.role === 'OWNER') {
              this.router.navigate(['/owner-dashboard']);
            } else {
              this.router.navigate(['/user-dashboard']);
            }
          }, 1000);
        },
        error: (err) => {
          console.error('Registration failed', err);
          this.errorMessage = 'Registration failed. Please try again.';
        }
      });
    }
  }
}
