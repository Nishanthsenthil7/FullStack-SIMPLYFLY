import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent {

  constructor(private router: Router) {}

  logout(): void {
    // Clear session or local storage if you use it
    localStorage.clear();
    // Navigate to login page
    this.router.navigate(['/login']);
  }
}
