import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-interface',
  templateUrl: './interface.component.html',
  styleUrls: ['./interface.component.css']
})
export class InterfaceComponent implements OnInit {
  showLoginPanel = false;
  step = 0;

  constructor(private router: Router) {}

  ngOnInit(): void {}

  toggleLogin(): void {
    this.showLoginPanel = !this.showLoginPanel;
    if (this.showLoginPanel) {
      this.runStepAnimation();
    }
  }

  runStepAnimation(): void {
    this.step = 0;
    setTimeout(() => this.step = 1, 100);     // Show heading
    setTimeout(() => this.step = 2, 1500);    // Show subtext
    setTimeout(() => this.step = 3, 3000);    // Show login button
  }

  goToLogin(): void {
    this.showLoginPanel = false;
    this.router.navigate(['/login']); // ⬅️ Navigates to login page
  }
}
