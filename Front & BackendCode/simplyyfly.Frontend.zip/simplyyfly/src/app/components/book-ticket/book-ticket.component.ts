import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BookingService } from '../../services/booking.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-ticket',
  templateUrl: './book-ticket.component.html'
})
export class BookTicketComponent implements OnInit {
  bookingForm: FormGroup;
  selectedFlight: any;

  constructor(
    private fb: FormBuilder,
    private bookingService: BookingService,
    private router: Router
  ) {
    this.bookingForm = this.fb.group({
      flightId: ['', Validators.required],
      seatCount: [1, [Validators.required, Validators.min(1)]],
      travelDate: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    const storedFlight = localStorage.getItem('selectedFlight');
    if (storedFlight) {
      this.selectedFlight = JSON.parse(storedFlight);

      // ✅ Ensure selectedFlight has ID
      if (!this.selectedFlight.id) {
        alert('Error: Flight ID is missing. Cannot proceed with booking.');
        return;
      }

      // ✅ Patch form values
      this.bookingForm.patchValue({
        flightId: this.selectedFlight.id,
        travelDate: this.selectedFlight.departureTime?.split('T')[0] || ''
      });
    }
  }

  onSubmit(): void {
    if (this.bookingForm.valid) {
      this.bookingService.bookTicket(this.bookingForm.value).subscribe({
        next: () => {
          alert('Booking successful!');
          this.router.navigate(['/user-dashboard/bookings']);
        },
        error: (err: any) => {
          console.error('Booking failed', err);
          alert('Booking failed. Please try again.');
        }
      });
    }
  }
}
