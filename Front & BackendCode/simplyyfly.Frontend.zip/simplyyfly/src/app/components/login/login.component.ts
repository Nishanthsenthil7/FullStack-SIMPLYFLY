import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      this.errorMessage = 'Please enter valid email and password.';
      return;
    }

    this.authService.login(this.loginForm.value).subscribe({
      next: (res) => {
        localStorage.setItem('token', res.token);
        localStorage.setItem('username', res.name);
        localStorage.setItem('role', res.role);

        const role = this.authService.getUserRole();
        if (role === 'USER') {
          this.router.navigate(['/user-dashboard']);
        } else if (role === 'ADMIN') {
          this.router.navigate(['/admin-dashboard']);
        } else if (role === 'OWNER') {
          this.router.navigate(['/owner-dashboard']);
        } else {
          this.errorMessage = 'Unknown user role.';
        }
      },
      error: () => {
        this.errorMessage = 'Invalid email or password.';
      }
    });
  }
}
