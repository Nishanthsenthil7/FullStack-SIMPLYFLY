import { Component, OnInit } from '@angular/core';
import { BookingService } from '../../services/booking.service';

@Component({
  selector: 'app-user-bookings',
  templateUrl: './user-bookings.component.html',
  styleUrls: ['./user-bookings.component.css']
})
export class UserBookingsComponent implements OnInit {
  bookings: any[] = [];
  username: string = '';
  noBookings = false;
  message: string = ''; // ✅ To support message binding in template

  constructor(private bookingService: BookingService) {}

  ngOnInit(): void {
    this.username = localStorage.getItem('username') || 'Guest';

    this.bookingService.getUserBookings().subscribe({
      next: (res: any) => {
        this.bookings = res;
        this.noBookings = this.bookings.length === 0;
      },
      error: (err) => {
        console.error('Error loading bookings:', err);
        this.noBookings = true;
        this.message = '❌ Failed to load bookings.';
      }
    });
  }

  cancelBooking(id: number): void {
    if (confirm('Are you sure you want to cancel this booking?')) {
      this.bookingService.cancelBooking(id).subscribe({
        error: () => {
          this.message = 'Booking cancelled successfully.';
          this.ngOnInit(); // Reload bookings
        },
        
      });
    }
  }

  downloadPdf(bookingId: number): void {
    this.bookingService.downloadBookingPdf(bookingId).subscribe({
      next: (blob: Blob) => {
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `booking-${bookingId}.pdf`;
        link.click();
        window.URL.revokeObjectURL(url);
      },
      error: (err) => {
        console.error('PDF download failed:', err);
        this.message = '❌ Failed to download PDF.';
      }
    });
  }
}
