import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  users: any[] = [];
  selectedUser: any = null;
  errorMessage = '';

  constructor(private http: HttpClient, private authService: AuthService) {}

  ngOnInit(): void {
    this.fetchUsers();
  }

  // ✅ Fetch all users from backend
  fetchUsers(): void {
    this.http.get<any[]>('http://localhost:8081/api/users').subscribe({
      next: (res) => {
        this.users = res;
      },
      error: (err) => {
        console.error('Failed to load users', err);
        this.errorMessage = 'Could not load users.';
      }
    });
  }

  // ✅ Get single user details
  getUserById(id: number): void {
    this.http.get<any>(`http://localhost:8081/api/users/${id}`).subscribe({
      next: (res) => {
        this.selectedUser = res;
      },
      error: (err) => {
        console.error('Failed to fetch user', err);
        this.errorMessage = 'User not found.';
      }
    });
  }

  // ✅ Delete user with confirmation and error alert
  deleteUser(id: number): void {
    if (confirm('Are you sure you want to delete this user?')) {
      this.http.delete(`http://localhost:8081/api/users/${id}`).subscribe({
        next: () => {
          alert('User deleted successfully');
          this.users = this.users.filter(u => u.id !== id);
          this.selectedUser = null;
          this.errorMessage = '';
        },
        error: (err) => {
          const message =
            err?.error?.message ||
            err?.error ||
            'Could not delete user. Please try again.';
          alert('Error: ' + message);
          this.errorMessage = message;
          console.error('Delete user error:', err);
        }
        
      });
    }
  }

  // ✅ Logout admin
  logout(): void {
    this.authService.logout();
  }
}
