import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from '../../services/booking.service';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css'] // make sure your styles are linked
})
export class UserDashboardComponent implements OnInit {
  username: string = '';
  role: string = '';
  bookings: any[] = [];
  noBookings = false;
  flipped = false; // 🔁 Controls Profile card flip

  constructor(
    private bookingService: BookingService,
    private router: Router
  ) {}

  ngOnInit() {
    const userData = JSON.parse(localStorage.getItem('user') || '{}');
    this.username = userData.username || 'User';
    
    const currentRoute = this.router.url;
    if (currentRoute.includes('bookings') || currentRoute.includes('user-dashboard')) {
      this.loadBookings();
    }
  }

  // ✅ Flip animation trigger for Profile
  goToProfile(): void {
    if (!this.flipped) {
      this.flipped = true;
      setTimeout(() => this.goToRoute(), 1000); // delay to allow flip animation
    }
  }

  goToRoute(): void {
    this.router.navigate(['/profile']);
  }

  loadBookings(): void {
    this.bookingService.getUserBookings().subscribe({
      next: (res: any) => {
        this.bookings = res;
        this.noBookings = this.bookings.length === 0;
      },
      error: (err) => {
        console.error('Error loading bookings:', err);
        this.noBookings = true;
      }
    });
  }

  cancelBooking(id: number): void {
    if (confirm('Are you sure you want to cancel this booking?')) {
      this.bookingService.cancelBooking(id).subscribe({
        next: () => {
          alert('Booking cancelled successfully.');
          this.loadBookings(); // Refresh list
        },
        error: (err) => {
          console.error('Cancel failed:', err);
          alert('Failed to cancel booking.');
        }
      });
    }
  }

  downloadTicket(bookingId: number): void {
    this.bookingService.downloadBookingPdf(bookingId).subscribe({
      next: (blob: Blob) => {
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `booking-${bookingId}.pdf`;
        link.click();
        URL.revokeObjectURL(url);
      },
      error: (err) => {
        console.error('Download failed:', err);
        alert('Failed to download ticket.');
      }
    });
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    this.router.navigate(['/login']);
  }
  
}
