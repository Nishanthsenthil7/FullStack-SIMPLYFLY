import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-owner-dashboard',
  templateUrl: './owner-dashboard.component.html',
  styleUrls: ['./owner-dashboard.component.css']
})
export class OwnerDashboardComponent implements OnInit {
  flightForm!: FormGroup;
  routeForm!: FormGroup;
  message: string = '';
  flights: any[] = [];
  routes: any[] = [];

  constructor(private fb: FormBuilder, private http: HttpClient) {}

  ngOnInit(): void {
    this.flightForm = this.fb.group({
      flightNumber: ['', Validators.required],
      flightName: ['', Validators.required],
      routeId: ['', Validators.required],
      totalSeats: ['', Validators.required],
      fare: ['', Validators.required],
      baggageCheckin: [''],
      departureTime: ['', Validators.required],
      arrivalTime: ['', Validators.required]
    });

    this.routeForm = this.fb.group({
      origin: ['', Validators.required],
      destination: ['', Validators.required],
      distanceInKm: ['', Validators.required]
    });

    this.getAllFlights();
    this.getAllRoutes();
  }

  addFlight(): void {
    if (this.flightForm.invalid) return;

    const headers = new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('token')}`
    });

    const formData = { ...this.flightForm.value };

    this.http.post('http://localhost:8081/api/flights', formData, { headers }).subscribe({
      next: () => {
        this.message = '✅ Flight added successfully!';
        this.flightForm.reset();
        this.getAllFlights();
      },
      error: (err) => {
        this.message = '❌ Failed to add flight.';
        console.error(err);
      }
    });
  }

  addRoute(): void {
    if (this.routeForm.invalid) return;

    const headers = new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('token')}`
    });

    this.http.post('http://localhost:8081/api/routes', this.routeForm.value, { headers }).subscribe({
      next: () => {
        this.message = '✅ Route added successfully!';
        this.routeForm.reset();
        this.getAllRoutes();
      },
      error: (err) => {
        this.message = '❌ Failed to add route.';
        console.error(err);
      }
    });
  }

  getAllFlights(): void {
    const headers = new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('token')}`
    });

    this.http.get<any[]>('http://localhost:8081/api/flights', { headers }).subscribe({
      next: (res) => {
        this.flights = res;
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  getAllRoutes(): void {
    const headers = new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('token')}`
    });

    this.http.get<any[]>('http://localhost:8081/api/routes', { headers }).subscribe({
      next: (res) => {
        this.routes = res;
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  logout(): void {
    localStorage.clear();
    location.reload();
  }
}
