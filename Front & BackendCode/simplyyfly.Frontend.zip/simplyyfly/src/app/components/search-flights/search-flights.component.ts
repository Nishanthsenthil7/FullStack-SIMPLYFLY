import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FlightService } from '../../services/flight.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-flights',
  templateUrl: './search-flights.component.html'
})
export class SearchFlightsComponent implements OnInit {
  searchForm: FormGroup;
  flights: any[] = [];
  noResults = false;

  constructor(
    private fb: FormBuilder,
    private flightService: FlightService,
    private router: Router
  ) {
    this.searchForm = this.fb.group({
      origin: ['', Validators.required],
      destination: ['', Validators.required],
      departureDate: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  onSearch(): void {
    if (this.searchForm.valid) {
      const payload = this.searchForm.value;

      this.flightService.searchFlights(payload).subscribe({
        next: (res) => {
          console.log('✅ Flights received:', res);
          this.flights = res;
          this.noResults = res.length === 0;
        },
        error: () => {
          this.flights = [];
          this.noResults = true;
        }
      });
    }
  }

  bookFlight(flight: any): void {
    localStorage.setItem('selectedFlight', JSON.stringify(flight));
    this.router.navigate(['/user-dashboard/book-ticket']);
  }
}
