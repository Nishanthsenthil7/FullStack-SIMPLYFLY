import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AdminService } from '../../services/admin.service';

interface Booking {
  id: number;
  status: string;
  bookingDate: string;
  flight: {
    flightNumber: string;
  };
}

interface UserDetailsResponse {
  id: number;
  name: string;
  email: string;
  contactNumber: string;
  address: string;
  role: string;
  bookings: Booking[];
}

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
})
export class UserDetailsComponent implements OnInit {
  userId!: number;
  userDetails!: UserDetailsResponse;
  loading: boolean = true;
  errorMessage: string = '';

  constructor(
    private route: ActivatedRoute,
    private adminService: AdminService
  ) {}

  ngOnInit(): void {
    this.userId = +this.route.snapshot.paramMap.get('id')!;
    this.adminService.getUserDetails(this.userId).subscribe({
      next: (data) => {
        this.userDetails = data;
        this.loading = false;
      },
      error: (err) => {
        this.errorMessage = 'Failed to load user details.';
        console.error(err);
        this.loading = false;
      }
    });
  }
}
