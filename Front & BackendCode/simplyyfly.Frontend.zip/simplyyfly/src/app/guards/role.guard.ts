import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const expectedRole = route.data['role'];        // e.g., 'USER', 'OWNER', 'ADMIN'
    const userRole = this.authService.getUserRole(); // From JWT

    if (!userRole) {
      this.router.navigate(['/login']);
      return false;
    }

    if (userRole === expectedRole) {
      return true;
    }

    // Redirect user to their appropriate dashboard
    switch (userRole) {
      case 'USER':
        this.router.navigate(['/user-dashboard']);
        break;
      case 'OWNER':
        this.router.navigate(['/owner-dashboard']);
        break;
      case 'ADMIN':
        this.router.navigate(['/admin-dashboard']);
        break;
      default:
        this.router.navigate(['/login']);
    }

    return false;
  }
}
