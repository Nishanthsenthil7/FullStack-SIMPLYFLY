import { FlightFilterPipe } from './flight-filter.pipe';

describe('FlightFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new FlightFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
