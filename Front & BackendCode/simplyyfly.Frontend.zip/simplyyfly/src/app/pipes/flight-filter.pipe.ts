import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'flightFilter'
})
export class FlightFilterPipe implements PipeTransform {
  transform(flights: any[], searchTerm: string): any[] {
    if (!flights || !searchTerm) {
      return flights;
    }

    const lowerSearch = searchTerm.toLowerCase();

    return flights.filter(flight =>
      flight.flightNumber?.toLowerCase().includes(lowerSearch) ||
      flight.origin?.toLowerCase().includes(lowerSearch) ||
      flight.destination?.toLowerCase().includes(lowerSearch)
    );
  }
}
